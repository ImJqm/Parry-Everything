package net.imjqm.parryeverything.event;

import net.imjqm.parryeverything.ParryEverything;
import net.imjqm.parryeverything.particle.ParryParticleProvider;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.*;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.imjqm.parryeverything.particle.*;

@Mod.EventBusSubscriber(modid = ParryEverything.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT) 
public class ClientModEvents {
  @SubscribeEvent
  public static void onRegisterParticlesFactories(RegisterParticleProvidersEvent event) {
    event.registerSpriteSet(ModParticles.PARRY_SPARK.get(), ParryParticleProvider::new);
  }
  
}
